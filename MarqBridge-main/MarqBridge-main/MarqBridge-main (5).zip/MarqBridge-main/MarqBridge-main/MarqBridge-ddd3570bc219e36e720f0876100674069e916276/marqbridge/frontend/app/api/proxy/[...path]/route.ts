import { NextRequest, NextResponse } from 'next/server'

// TODO production: add rate limiting middleware here
// Recommended: upstash/ratelimit or nginx upstream limit

const BACKEND = process.env.BACKEND_URL || 'http://localhost:8000'

export async function GET(req: NextRequest, context: any) {
  const params = await context.params
  const path = params.path.join('/')
  const url = `${BACKEND}/${path}${req.nextUrl.search}`
  try {
    const res = await fetch(url, {
      headers: { 'Content-Type': 'application/json' },
      cache: 'no-store',
    })

    // Handle file downloads (CSV exports)
    const contentType = res.headers.get('content-type')
    if (contentType?.includes('text/csv') || res.headers.get('content-disposition')) {
      const buffer = await res.arrayBuffer()
      return new NextResponse(buffer, {
        status: res.status,
        headers: {
          'Content-Type': contentType || 'text/csv',
          'Content-Disposition': res.headers.get('content-disposition') || '',
        },
      })
    }

    const data = await res.json()
    return NextResponse.json(data, { status: res.status })
  } catch (e) {
    return NextResponse.json({ error: 'Backend unavailable' }, { status: 503 })
  }
}

export async function POST(req: NextRequest, context: any) {
  const params = await context.params
  const path = params.path.join('/')
  const url = `${BACKEND}/${path}`
  try {
    const body = await req.json()
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
      cache: 'no-store',
    })
    const data = await res.json()
    return NextResponse.json(data, { status: res.status })
  } catch (e) {
    return NextResponse.json({ error: 'Backend unavailable' }, { status: 503 })
  }
}

export async function PATCH(req: NextRequest, context: any) {
  const params = await context.params
  const path = params.path.join('/')
  const url = `${BACKEND}/${path}`
  try {
    const body = await req.json()
    const res = await fetch(url, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
      cache: 'no-store',
    })
    const data = await res.json()
    return NextResponse.json(data, { status: res.status })
  } catch (e) {
    return NextResponse.json({ error: 'Backend unavailable' }, { status: 503 })
  }
}
