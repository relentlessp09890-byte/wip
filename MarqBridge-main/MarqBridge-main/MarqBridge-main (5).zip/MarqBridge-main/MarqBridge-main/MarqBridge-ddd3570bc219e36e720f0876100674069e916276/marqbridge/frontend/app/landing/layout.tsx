import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'MarqBridge — Risk-first trading OS',
  description: 'Professional risk management for traders. Pre-trade gate, live margin monitoring, decision journal.',
  keywords: ['trading', 'risk management', 'margin', 'crypto', 'forex'],
}

export default function LandingLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body>
        {children}
      </body>
    </html>
  )
}