'use client'
import { useState, useEffect } from 'react'
import { useMarqStore } from '@/store/useMarqStore'
import Sidebar from '@/components/layout/Sidebar'
import TopBar from '@/components/layout/TopBar'
import StatePanel from '@/components/panels/StatePanel'
import { ExposurePanel } from '@/components/panels/ExposurePanel'
import DecisionsPanel from '@/components/panels/DecisionsPanel'
import IntegrationsPanel from '@/components/panels/IntegrationsPanel'
import FirstRun from '@/components/onboarding/FirstRun'
import { ErrorBoundary } from '@/components/ui/ErrorBoundary'
import dynamic from 'next/dynamic'
import { NewsItemSkeleton } from '@/components/ui/Skeleton'

const LogPanel = dynamic(
  () => import('@/components/panels/LogPanel'),
  {
    loading: () => (
      <div className="p-6 text-gray-700 text-sm">
        Loading journal...
      </div>
    ),
    ssr: false,
  }
)

const NewsPanel = dynamic(
  () => import('@/components/panels/NewsPanel'),
  {
    loading: () => (
      <div className="p-6 space-y-3">
        <NewsItemSkeleton />
        <NewsItemSkeleton />
        <NewsItemSkeleton />
      </div>
    ),
    ssr: false,
  }
)

const PANEL_MAP: Record<string, React.ReactNode> = {
  STATE: (
    <ErrorBoundary name="State panel">
      <StatePanel />
    </ErrorBoundary>
  ),
  POSITIONS: (
    <ErrorBoundary name="Exposure panel">
      <ExposurePanel />
    </ErrorBoundary>
  ),
  DECISIONS: (
    <ErrorBoundary name="Decisions panel">
      <DecisionsPanel />
    </ErrorBoundary>
  ),
  LOG: (
    <ErrorBoundary name="Log panel">
      <LogPanel />
    </ErrorBoundary>
  ),
  NEWS: (
    <ErrorBoundary name="News panel">
      <NewsPanel />
    </ErrorBoundary>
  ),
  INTEGRATIONS: (
    <ErrorBoundary name="Integrations panel">
      <IntegrationsPanel />
    </ErrorBoundary>
  ),
}

export default function Home() {
  const { activeTab, setActiveTab } = useMarqStore()
  const [onboarded, setOnboarded] = useState<boolean | null>(null)

  useEffect(() => {
    const v = localStorage.getItem('marq_onboarded')
    setOnboarded(v === '1')
  }, [])

  if (onboarded === null) {
    return (
      <div className="min-h-screen bg-terminal-bg flex items-center justify-center">
        <div className="w-8 h-8 rounded-lg bg-brand-gold/15 border border-brand-gold/30 flex items-center justify-center animate-pulse">
          <span className="text-brand-gold font-mono font-bold text-sm">M</span>
        </div>
      </div>
    )
  }

  if (!onboarded) {
    return (
      <FirstRun
        onComplete={() => {
          setOnboarded(true)
          setActiveTab('INTEGRATIONS')
        }}
      />
    )
  }

  return (
    <div className="flex flex-col h-screen overflow-hidden bg-terminal-bg">
      <TopBar />
      <div className="flex flex-1 overflow-hidden">
        <Sidebar />
        <main className="flex-1 overflow-y-auto">
          {PANEL_MAP[activeTab] ?? PANEL_MAP['STATE']}
        </main>
      </div>
    </div>
  )
}
