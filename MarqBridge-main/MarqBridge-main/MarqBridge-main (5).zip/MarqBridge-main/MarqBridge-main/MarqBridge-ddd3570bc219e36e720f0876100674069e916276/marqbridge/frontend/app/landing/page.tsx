'use client'
import { useRouter } from 'next/navigation'
import { useState, useEffect } from 'react'

const STATS = [
  { value: '2s',    label: 'Gate evaluation speed' },
  { value: '4',     label: 'Alert tiers per position' },
  { value: '8',     label: 'Supported brokers' },
  { value: '100%',  label: 'Broker-mirrored pricing' },
]

const PROBLEMS = [
  {
    problem: 'You enter a trade and realize 5 minutes later it was too large.',
    solution: 'Tactical Simulator evaluates margin impact before you touch the button.',
  },
  {
    problem: 'You keep trading after three losses. You know you should stop.',
    solution: 'Circuit Breaker locks new entries automatically. No willpower needed.',
  },
  {
    problem: 'News moves your position and you find out an hour later.',
    solution: 'AI News Filter surfaces only what affects your open positions. Nothing else.',
  },
  {
    problem: 'You don\'t know why you keep losing. You can\'t see the pattern.',
    solution: 'Decision Journal logs every trade with emotional context. The pattern becomes visible.',
  },
]

const TIERS = [
  {
    name:    'Core',
    price:   'Free',
    period:  'forever',
    desc:    'For individual traders getting started with risk-first discipline.',
    features: [
      '1 broker connection',
      'Pre-trade risk gate',
      'Margin stress test',
      '30-day decision journal',
      'Session heat score',
      'Circuit breaker',
      'Basic liquidation alerts',
    ],
    cta:     'Start free',
    accent:  false,
  },
  {
    name:    'Pro',
    price:   '$29',
    period:  '/month',
    desc:    'For active traders who want behavioral intelligence and AI insights.',
    features: [
      'Everything in Core',
      'Unlimited journal history',
      'AI news intelligence',
      'Discipline scoring + trends',
      'Loss pattern detection',
      'Multi-tier liq alerts + sounds',
      'CSV + performance export',
      'Market regime classifier',
    ],
    cta:     'Start Pro',
    accent:  true,
  },
  {
    name:    'Prop Desk',
    price:   '$99',
    period:  '/month',
    desc:    'For prop firms and professional teams with shared risk rules.',
    features: [
      'Everything in Pro',
      'Up to 10 trader accounts',
      'Shared circuit breaker rules',
      'Team risk dashboard',
      'Compliance export (PDF)',
      'Risk rule enforcement',
      'Priority support',
    ],
    cta:     'Contact us',
    accent:  false,
  },
]

export default function LandingPage() {
  const router  = useRouter()
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    const h = () => setScrolled(window.scrollY > 40)
    window.addEventListener('scroll', h)
    return () => window.removeEventListener('scroll', h)
  }, [])

  function goToApp(skip = false) {
    localStorage.setItem('marq_saw_landing', '1')
    if (skip) localStorage.setItem('marq_onboarded', '1')
    router.push('/')
  }

  return (
    <div className="min-h-screen bg-terminal-bg text-white">

      {/* Sticky nav */}
      <nav className={`sticky top-0 z-50 transition-all ${
        scrolled
          ? 'bg-terminal-bg/90 backdrop-blur-md border-b border-terminal-border'
          : 'bg-transparent'
      }`}>
        <div className="max-w-5xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-brand-gold/15 border border-brand-gold/30 flex items-center justify-center">
              <span className="text-brand-gold font-mono font-bold text-xs">M</span>
            </div>
            <span className="text-white font-medium">MarqBridge</span>
          </div>
          <div className="hidden md:flex items-center gap-6 text-xs text-gray-500">
            <a href="#problem" className="hover:text-gray-300 transition-colors">Why</a>
            <a href="#features" className="hover:text-gray-300 transition-colors">Features</a>
            <a href="#pricing" className="hover:text-gray-300 transition-colors">Pricing</a>
          </div>
          <button onClick={() => goToApp()}
            className="text-xs px-4 py-2 rounded-lg border border-brand-gold/40 text-brand-gold bg-brand-gold/8 hover:bg-brand-gold/15 transition-colors">
            Open platform →
          </button>
        </div>
      </nav>

      {/* Hero */}
      <section className="max-w-4xl mx-auto px-6 pt-20 pb-16 text-center">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-brand-gold/15 bg-brand-gold/5 mb-8">
          <span className="w-1.5 h-1.5 rounded-full bg-brand-gold animate-pulse" />
          <span className="text-2xs text-brand-gold">
            Risk-first trading OS · Crypto · Forex · Indian markets
          </span>
        </div>

        <h1 className="text-5xl md:text-6xl font-medium leading-tight mb-6">
          Do less.<br />
          <span className="text-brand-gold">Do it right.</span>
        </h1>

        <p className="text-lg text-gray-500 leading-relaxed max-w-xl mx-auto mb-10">
          MarqBridge guards every trade before you take it.
          Pre-trade risk gate. Circuit breaker. Liquidation alerts.
          Decision journal. Not a signal platform — a discipline engine.
        </p>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-3 mb-6">
          <button onClick={() => goToApp(true)}
            className="w-full sm:w-auto px-7 py-3.5 rounded-xl border border-brand-gold/40 text-brand-gold bg-brand-gold/10 hover:bg-brand-gold/20 text-sm font-medium transition-all active:scale-[0.98]">
            Try demo — no signup required
          </button>
          <button onClick={() => goToApp()}
            className="w-full sm:w-auto px-7 py-3.5 rounded-xl border border-terminal-border text-gray-400 text-sm hover:border-terminal-muted hover:text-gray-300 transition-colors">
            Connect your broker →
          </button>
        </div>

        <p className="text-2xs text-gray-700">
          Read-only API access only · No trading · Your data stays local
        </p>
      </section>

      {/* Stats bar */}
      <section className="border-y border-terminal-border">
        <div className="max-w-4xl mx-auto px-6 py-8 grid grid-cols-2 lg:grid-cols-4 gap-6">
          {STATS.map(s => (
            <div key={s.label} className="text-center">
              <p className="text-3xl font-mono font-medium text-brand-gold mb-1">{s.value}</p>
              <p className="text-xs text-gray-600">{s.label}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Problem → Solution */}
      <section id="problem" className="max-w-4xl mx-auto px-6 py-20 space-y-4">
        <p className="label-caps text-center mb-2">Why MarqBridge exists</p>
        <p className="text-xs text-gray-600 text-center mb-10 max-w-md mx-auto">
          Every feature was built because a real trader lost money
          without it.
        </p>
        <div className="space-y-3">
          {PROBLEMS.map((p, i) => (
            <div key={i} className="bg-terminal-surface border border-terminal-border rounded-xl p-5 grid grid-cols-1 lg:grid-cols-2 gap-4">
              <div>
                <p className="text-2xs text-risk-danger mb-2 label-caps">The problem</p>
                <p className="text-sm text-gray-400 leading-relaxed">{p.problem}</p>
              </div>
              <div>
                <p className="text-2xs text-risk-safe mb-2 label-caps">MarqBridge</p>
                <p className="text-sm text-gray-300 leading-relaxed">{p.solution}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Pricing */}
      <section id="pricing" className="max-w-5xl mx-auto px-6 py-20 space-y-8">
        <div className="text-center">
          <p className="label-caps mb-2">Pricing</p>
          <h2 className="text-2xl font-medium text-white mb-3">Start free. Scale when ready.</h2>
          <p className="text-sm text-gray-500 max-w-sm mx-auto">
            Core risk protection is free forever.
            Advanced intelligence is Pro.
            Team risk management is Prop Desk.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
          {TIERS.map(tier => (
            <div key={tier.name} className={`rounded-2xl p-6 space-y-5 ${
              tier.accent
                ? 'border-2 border-brand-gold/30 bg-brand-gold/3'
                : 'border border-terminal-border bg-terminal-surface'
            }`}>
              {tier.accent && (
                <div className="text-2xs text-brand-gold border border-brand-gold/30 rounded px-2 py-0.5 inline-block bg-brand-gold/10">
                  Most popular
                </div>
              )}
              <div>
                <p className="text-xs text-gray-600 mb-1">{tier.name}</p>
                <div className="flex items-baseline gap-1">
                  <span className={`text-3xl font-mono font-medium ${tier.accent ? 'text-brand-gold' : 'text-white'}`}>
                    {tier.price}
                  </span>
                  <span className="text-xs text-gray-600">{tier.period}</span>
                </div>
                <p className="text-xs text-gray-600 mt-2 leading-relaxed">{tier.desc}</p>
              </div>

              <div className="space-y-2">
                {tier.features.map((f, i) => (
                  <div key={i} className="flex items-start gap-2 text-xs">
                    <span className={`mt-0.5 flex-shrink-0 ${tier.accent ? 'text-brand-gold' : 'text-risk-safe'}`}>—</span>
                    <span className="text-gray-400">{f}</span>
                  </div>
                ))}
              </div>

              <button
                onClick={() => {
                  if (tier.name === 'Prop Desk') {
                    window.open('mailto:hello@marqbridge.io', '_blank')
                  } else {
                    goToApp(tier.name === 'Core')
                  }
                }}
                className={`w-full py-2.5 rounded-xl text-sm font-medium transition-all active:scale-[0.98] ${
                  tier.accent
                    ? 'border border-brand-gold/40 text-brand-gold bg-brand-gold/10 hover:bg-brand-gold/20'
                    : 'border border-terminal-border text-gray-400 hover:border-terminal-muted hover:text-gray-300'
                }`}>
                {tier.cta}
              </button>
            </div>
          ))}
        </div>
      </section>

      {/* Final CTA */}
      <section className="max-w-4xl mx-auto px-6 pb-20">
        <div className="bg-terminal-surface border border-brand-gold/15 rounded-2xl p-10 text-center space-y-4">
          <h2 className="text-2xl font-medium text-white">The best trade is the one you don't take.</h2>
          <p className="text-sm text-gray-500">
            Start with the free demo. No account, no API key, no commitment.
          </p>
          <button onClick={() => goToApp(true)}
            className="px-8 py-3.5 rounded-xl border border-brand-gold/40 text-brand-gold bg-brand-gold/10 hover:bg-brand-gold/20 text-sm font-medium transition-all active:scale-[0.98]">
            Try demo now — free forever →
          </button>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-terminal-border px-6 py-6">
        <div className="max-w-5xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="text-gray-700 text-xs">MarqBridge</span>
            <span className="text-gray-800">·</span>
            <span className="text-gray-700 text-xs">Risk-first trading OS</span>
          </div>
          <div className="flex items-center gap-4 text-2xs text-gray-800">
            <span>Read-only API</span>
            <span>·</span>
            <span>No predictions</span>
            <span>·</span>
            <span>Data stays local</span>
          </div>
        </div>
      </footer>
    </div>
  )
}
