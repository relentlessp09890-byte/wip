import { useMarqStore } from '@/store/useMarqStore'
import { normalizeSide } from './normalizeSide'
import { evaluateAlerts, evaluateSessionAlerts, notifyBrokerConnected, notifyBrokerDisconnected } from './riskAlerts'
import { evaluateLiquidationAlerts, requestNotificationPermission } from './liquidationEngine'
import { useNotifStore } from '@/components/ui/NotificationSystem'

let ws: WebSocket | null = null
let reconnectTimer: ReturnType<typeof setTimeout> | null = null
let reconnectAttempts = 0
let prevCbLocked = false
const MAX_RECONNECT = 5

function getWsUrl(): string {
  if (typeof window === 'undefined') return 'ws://localhost:8000'

  const host = window.location.hostname

  // Codespaces: hostname is like opulent-waffle-xxx-3000.app.github.dev
  // Backend WS is on port 8000, same subdomain with port replaced
  if (host.includes('.app.github.dev')) {
    const wsHost = host.replace('-3000.app.github.dev', '-8000.app.github.dev')
    return `wss://${wsHost}`
  }

  return 'ws://localhost:8000'
}

export function connectWS() {
  if (typeof window === 'undefined') return
  if (ws && ws.readyState === WebSocket.OPEN) return
  const wsUrl = getWsUrl()

  ws = new WebSocket(`${wsUrl}/ws`)

  ws.onopen = () => {
    reconnectAttempts = 0
    const state = useMarqStore.getState()
    state.setConnected(true)
    state.setLatency(Date.now())
    requestNotificationPermission()
    notifyBrokerConnected(state.broker?.exchange || 'broker')
    console.log('[MarqBridge WS] Connected')
  }

  ws.onmessage = (event) => {
    try {
      const msg = JSON.parse(event.data)
      const store = useMarqStore.getState()

      if (msg.type === 'SESSION_SWITCH') {
        // ATOMIC: clear everything first
        store.setConnected(false)
        store.setPositions([])
        store.setAccount({
          equity: 0,
          balance: 0,
          marginLevel: 0,
          freeMargin: 0,
          usedMargin: 0,
          liquidationProximity: 0,
          riskLevel: 'SAFE',
          heat: 'NORMAL',
          lastUpdated: Date.now(),
        })

        if (msg.mode === 'disconnected') return

        // Then set new state atomically
        if (msg.account) {
          store.setAccount({
            equity: Number(msg.account.equity ?? 0),
            balance: Number(msg.account.balance ?? 0),
            marginLevel: Number(msg.account.margin_level ?? 0),
            freeMargin: Number(msg.account.free_margin ?? 0),
            usedMargin: Number(msg.account.used_margin ?? 0),
            liquidationProximity: Number(msg.account.liquidation_proximity ?? 0),
            riskLevel: msg.account.risk_level ?? 'SAFE',
            heat: msg.account.heat ?? 'NORMAL',
            lastUpdated: Number(msg.account.last_updated ?? Date.now()),
          })
        }

        if (Array.isArray(msg.positions)) {
          store.setPositions(
            msg.positions.map((p: any) => ({
              id: p.id,
              ticker: p.ticker,
              side: normalizeSide(p.side),
              size: p.size,
              entryPrice: p.entry_price,
              currentPrice: p.current_price,
              pnl: p.pnl,
              pnlPct: p.pnl_pct,
              marginUsed: p.margin_used,
              liquidationPrice: p.liquidation_price,
              distanceToLiq: p.distance_to_liq,
              openedAt: p.opened_at,
            }))
          )
        }

        store.setConnected(true)

        // Notify user of the switch
        const { push } = useNotifStore.getState()
        if (msg.mode === 'demo') {
          push({
            level: 'info',
            title: 'Demo mode active',
            message: 'Showing simulated data. Connect a real broker for live account.',
            persistent: false,
          })
        } else if (msg.mode === 'live') {
          push({
            level: 'success',
            title: `${msg.exchange?.toUpperCase()} connected`,
            message: `Live data streaming. Equity: $${(msg.account?.equity ?? 0).toLocaleString()}`,
            persistent: false,
          })
        }

        return
      }

      if (msg.type === 'STATE_UPDATE') {
        if (msg.account) {
          store.setAccount({
            equity: Number(msg.account.equity ?? 0),
            balance: Number(msg.account.balance ?? 0),
            marginLevel: Number(msg.account.margin_level ?? 0),
            freeMargin: Number(msg.account.free_margin ?? 0),
            usedMargin: Number(msg.account.used_margin ?? 0),
            liquidationProximity: Number(msg.account.liquidation_proximity ?? 0),
            riskLevel: msg.account.risk_level ?? 'SAFE',
            heat: msg.account.heat ?? 'NORMAL',
            lastUpdated: Number(msg.account.last_updated ?? Date.now()),
          })
        }

        if (msg.positions) {
          store.setPositions(
            msg.positions.map((p: any) => ({
              id: String(p.id),
              ticker: String(p.ticker || 'UNKNOWN'),
              side: normalizeSide(p.side),
              size: Number(p.size ?? 0),
              entryPrice: Number(p.entry_price ?? 0),
              currentPrice: Number(p.current_price ?? 0),
              pnl: Number(p.pnl ?? 0),
              pnlPct: Number(p.pnl_pct ?? 0),
              marginUsed: Number(p.margin_used ?? 0),
              liquidationPrice: Number(p.liquidation_price ?? 0),
              distanceToLiq: Number(p.distance_to_liq ?? 999),
              openedAt: Number(p.opened_at ?? Date.now()),
            }))
          )
          evaluateLiquidationAlerts(store.positions)
        }

        if (msg.price_map && Object.keys(msg.price_map).length > 0) {
          // Extract price values from nested {price, pnl} objects
          const extractedPrices = Object.entries(msg.price_map).reduce(
            (acc, [ticker, data]) => {
              acc[ticker] = typeof data === 'object' && data !== null && 'price' in data
                ? Number(data.price ?? 0)
                : Number(data ?? 0)
              return acc
            },
            {} as Record<string, number>
          )
          useMarqStore.getState().setPriceMap(extractedPrices)
        }

        if (msg.market_type) {
          store.setMarketType(msg.market_type)
          console.debug('[MarqBridge WS] market_type', msg.market_type,
            'session_open', msg.session_open)
        }

        if (typeof msg.session_open === 'boolean') {
          store.setSessionOpen(msg.session_open)
          evaluateSessionAlerts(msg.session_open, msg.market_type ?? null)
        }

        if (msg.risk) {
          store.setRiskScore({
            overall: msg.risk.overall,
            axes: msg.risk.axes,
            level: msg.risk.level,
            heat: msg.risk.heat,
            ts: msg.risk.ts,
          })
        }

        if (msg.circuit_breaker) {
          if (msg.circuit_breaker.locked && !prevCbLocked) {
            useNotifStore.getState().push({
              level: 'critical',
              title: 'Circuit breaker activated',
              message: msg.circuit_breaker.reason || 'Session locked.',
              persistent: true,
            })
          }
          prevCbLocked = msg.circuit_breaker.locked
        }

        const state = useMarqStore.getState()
        if (state.account && state.riskScore) {
          evaluateAlerts(state.account, state.riskScore)
        }
      }
    } catch (e) {
      console.error('[MarqBridge WS] Parse error', e)
    }
  }

  ws.onclose = () => {
    useMarqStore.getState().setConnected(false)
    notifyBrokerDisconnected()
    scheduleReconnect()
  }

  ws.onerror = (err) => {
    console.error('[MarqBridge WS] Error', err)
    ws?.close()
  }
}

function scheduleReconnect() {
  if (reconnectAttempts >= MAX_RECONNECT) {
    console.warn('[MarqBridge WS] Max reconnect attempts reached')
    return
  }

  const delay = Math.min(1000 * 2 ** reconnectAttempts, 30000)
  reconnectAttempts += 1
  reconnectTimer = setTimeout(connectWS, delay)
}

export function disconnectWS() {
  if (reconnectTimer) clearTimeout(reconnectTimer)
  ws?.close()
  ws = null
}
