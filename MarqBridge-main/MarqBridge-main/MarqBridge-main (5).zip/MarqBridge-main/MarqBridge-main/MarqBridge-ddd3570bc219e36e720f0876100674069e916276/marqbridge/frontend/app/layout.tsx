import type { Metadata } from 'next'
import './globals.css'
import ClientProviders from '@/components/providers/ClientProviders'

export const metadata: Metadata = {
  title: 'MarqBridge — Risk-first trading OS',
  description: 'Professional risk management for traders. Pre-trade gate, live margin monitoring, decision journal.',
  keywords: ['trading', 'risk management', 'margin', 'crypto', 'forex'],
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body>
        <ClientProviders>
          {children}
        </ClientProviders>
      </body>
    </html>
  )
}
