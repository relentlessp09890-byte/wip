from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from routers import account, positions, risk, news
from services.broker_connector import broker
from services.risk_engine import risk_engine
from services.circuit_breaker import circuit_breaker
from services.market_config import get_exchange_market_type, is_market_open
from core.config import settings
from core.startup_check import check_environment
from core.connection_manager import manager
from database import init_db
import asyncio
import json
import os
import time as _time

check_environment()

app = FastAPI(
    title="MarqBridge API",
    description="Risk-first trading OS backend",
    version="2.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(account.router, prefix="/api/account", tags=["account"])
app.include_router(positions.router, prefix="/api/positions", tags=["positions"])
app.include_router(risk.router, prefix="/api/risk", tags=["risk"])
app.include_router(news.router, prefix="/api/news", tags=["news"])

class ConnectionManager:
    def __init__(self):
        self.active: list[WebSocket] = []

    async def connect(self, ws: WebSocket):
        await ws.accept()
        self.active.append(ws)

    def disconnect(self, ws: WebSocket):
        if ws in self.active:
            self.active.remove(ws)

    async def broadcast(self, data: dict):
        dead = []
        for ws in self.active:
            try:
                await ws.send_text(json.dumps(data))
            except Exception:
                dead.append(ws)
        for ws in dead:
            self.disconnect(ws)


_start_time = _time.time()

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await manager.connect(websocket)
    try:
        while True:
            await websocket.receive_text()
    except WebSocketDisconnect:
        manager.disconnect(websocket)

@app.on_event("startup")
async def on_startup():
    await init_db()
    asyncio.create_task(feed_loop())

_last_payload_hash = None

async def feed_loop():
    global _last_payload_hash
    while True:
        try:
            if broker.connected:
                account_state = await broker.get_account_state()
                positions = await broker.get_positions()

                # Only broadcast if state changed
                key_data = f"{account_state.equity:.2f}_{account_state.margin_level:.2f}_{len(positions)}"
                if key_data != _last_payload_hash:
                    _last_payload_hash = key_data
                    risk_score = risk_engine.score(account_state, positions)
                    cb_state = circuit_breaker.state()
                    market_type = get_exchange_market_type(broker.exchange_id or "binance")
                    session_open = is_market_open(market_type)

                    # Minimal price map — only price + pnl per position
                    price_map = {
                        p.ticker: {
                            "price": p.current_price,
                            "pnl": p.pnl,
                        }
                        for p in positions
                    }

                    await manager.broadcast({
                        "type": "STATE_UPDATE",
                        "account": account_state.dict(),
                        "positions": [p.dict() for p in positions],
                        "risk": risk_score,
                        "circuit_breaker": cb_state,
                        "price_map": price_map,
                        "market_type": market_type.value,
                        "session_open": session_open,
                        "demo": broker.demo_mode,
                        "ts": int(_time.time() * 1000),
                    })
        except Exception as e:
            print(f"[feed_loop] error: {e}")
        await asyncio.sleep(2)

@app.get("/status")
async def system_status():
    uptime = round(_time.time() - _start_time)
    market_type = get_exchange_market_type(broker.exchange_id or 'binance')
    session_open = is_market_open(market_type)
    return {
        "service": "MarqBridge",
        "version": "1.0.0",
        "uptime_seconds": uptime,
        "broker_connected": broker.connected,
        "broker_exchange": broker.exchange_id,
        "broker_last_sync": broker.last_sync,
        "ws_clients": len(manager.active),
        "circuit_breaker": circuit_breaker.state(),
        "market_type": market_type.value,
        "session_open": session_open,
        "environment": os.getenv("ENVIRONMENT", "development"),
    }

@app.get("/health")
async def health():
    return {
        "status": "online",
        "service": "MarqBridge",
        "broker_connected": broker.connected,
        "broker_exchange": broker.exchange_id,
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=settings.backend_port, reload=True)
